<?php
// Cambia esto con tu información de conexión.
$DATABASE_HOST = 'localhost';
$DATABASE_USER = 'root';
$DATABASE_PASS = '';
$DATABASE_NAME = 'phplogin';

// Intenta conectarte utilizando la información proporcionada.
$conn = mysqli_connect($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);

// Verifica si hay errores de conexión.
if ( mysqli_connect_errno() ) {
    // Si hay un error en la conexión, detén el script y muestra el error.
    exit('Fallo al conectar con MySQL: ' . mysqli_connect_error());
}
?>