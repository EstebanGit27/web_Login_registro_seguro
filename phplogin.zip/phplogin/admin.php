<?php
include 'config.php';

// Función para obtener todos los usuarios de la base de datos
function getUsers() {
    global $conn;
    $sql = "SELECT id, username FROM accounts";
    $result = $conn->query($sql);
    return $result->fetch_all(MYSQLI_ASSOC);
}

// Función para obtener los detalles de un usuario específico por ID
function getUserById($user_id) {
    global $conn;
    $stmt = $conn->prepare("SELECT id, username FROM accounts WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

// Función para crear un nuevo usuario
function createUser($username, $password) {
    global $conn;
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("INSERT INTO accounts (username, password) VALUES (?, ?)");
    $stmt->bind_param("ss", $username, $hashed_password);
    return $stmt->execute();
}

// Función para actualizar un usuario
function updateUser($user_id, $username, $password) {
    global $conn;
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("UPDATE users SET username = ?, password = ? WHERE id = ?");
    $stmt->bind_param("ssi", $username, $hashed_password, $user_id);
    return $stmt->execute();
}

// Función para eliminar un usuario
function deleteUser($user_id) {
    global $conn;
    $stmt = $conn->prepare("DELETE FROM accounts WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    return $stmt->execute();
}

// Procesar solicitudes de creación, actualización y eliminación de usuarios
if(isset($_POST['create'])) {
    createUser($_POST['username'], $_POST['password']);
}
if(isset($_POST['update'])) {
    updateUser($_POST['user_id'], $_POST['username'], $_POST['password']);
}
if(isset($_POST['delete'])) {
    deleteUser($_POST['user_id']);
}

// Obtener la lista de usuarios
$users = getUsers();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administrador de Usuarios</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            margin-top: 0;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
            text-align: left;
        }
        tr:hover {
            background-color: #f9f9f9;
        }
        input[type="text"], input[type="password"], input[type="submit"] {
            padding: 8px;
            margin-bottom: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        input[type="submit"] {
            background-color: #4caf50;
            color: #fff;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>

<div class="container">

    <h2>Administrador de Usuarios</h2>

    <table>
        <tr>
            <th>ID</th>
            <th>Nombre de Usuario</th>
            <th>Acciones</th>
        </tr>
        <?php foreach ($users as $user): ?>
            <tr>
                <td><?php echo $user['id']; ?></td>
                <td><?php echo $user['username']; ?></td>
                <td>
                    <form action="" method="post">
                        <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                        <input type="text" name="username" value="<?php echo $user['username']; ?>">
                        <input type="password" name="password" placeholder="Nueva contraseña">
                        <input type="submit" name="update" value="Actualizar">
                        <input type="submit" name="delete" value="Eliminar">
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>

    <h2>Crear Nuevo Usuario</h2>

    <form action="" method="post">
        <label>Nombre de usuario:</label>
        <input type="text" name="username">
        <label>Contraseña:</label>
        <input type="password" name="password">
        <input type="submit" name="create" value="Crear">
    </form>

</div>

</body>
</html>