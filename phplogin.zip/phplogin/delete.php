<?php
include 'config.php';

if(isset($_POST['delete'])) {
    $user_id = $_POST['user_id'];
    
    $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    
    if($stmt->execute()) {
        echo "Usuario eliminado correctamente.";
    } else {
        echo "Error al eliminar el usuario: " . $stmt->error;
    }
    $stmt->close();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Eliminar Usuario</title>
</head>
<body>

<h2>Eliminar Usuario</h2>

<form action="delete.php" method="post">
    <label>ID de usuario:</label><br>
    <input type="text" name="user_id"><br><br>
    <input type="submit" name="delete" value="Eliminar">
</form>

</body>
</html>