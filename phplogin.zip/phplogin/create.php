<?php
include 'config.php';

if(isset($_POST['create'])) {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    
    $stmt = $conn->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
    $stmt->bind_param("ss", $username, $password);
    
    if($stmt->execute()) {
        echo "Usuario creado correctamente.";
    } else {
        echo "Error al crear el usuario: " . $stmt->error;
    }
    $stmt->close();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Crear Usuario</title>
</head>
<body>

<h2>Crear Usuario</h2>

<form action="create.php" method="post">
    <label>Nombre de usuario:</label><br>
    <input type="text" name="username"><br>
    <label>Contraseña:</label><br>
    <input type="password" name="password"><br><br>
    <input type="submit" name="create" value="Crear">
</form>

</body>
</html>