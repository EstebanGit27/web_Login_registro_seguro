<?php
include 'config.php';

if(isset($_POST['update'])) {
    $user_id = $_POST['user_id'];
    $new_username = $_POST['new_username'];
    $new_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
    
    $stmt = $conn->prepare("UPDATE users SET username = ?, password = ? WHERE id = ?");
    $stmt->bind_param("ssi", $new_username, $new_password, $user_id);
    
    if($stmt->execute()) {
        echo "Usuario actualizado correctamente.";
    } else {
        echo "Error al actualizar el usuario: " . $stmt->error;
    }
    $stmt->close();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Actualizar Usuario</title>
</head>
<body>

<h2>Actualizar Usuario</h2>

<form action="update.php" method="post">
    <label>ID de usuario:</label><br>
    <input type="text" name="user_id"><br>
    <label>Nuevo nombre de usuario:</label><br>
    <input type="text" name="new_username"><br>
    <label>Nueva contraseña:</label><br>
    <input type="password" name="new_password"><br><br>
    <input type="submit" name="update" value="Actualizar">
</form>

</body>
</html>